<?php 
   include('server.php');
   
   if (!isset($_SESSION['username'])) {   
   	header('location: login.php');
   }
   if (isset($_GET['logout'])) {
   	session_destroy();
   	unset($_SESSION['username']);
   	header("location: login.php");
   }
   ?>
<html>
   <head>
      <title>Administrator</title>
      <?php include('-scripts.php'); ?>
   </head>
   <body class="bg-cc">
      <?php include('-header.php'); ?>
      <div class="pom-content">
         <div class="row">
            <div class="col">
               <div id="regBox" style="color: white;">
                  <h1 style="color:#FFF;">
                     <?php
                        echo "Dobro došli, ". $_SESSION['ime'] ."."; 
                        ?>
                  </h1>
                  <div class="form-bg">
                     <label>Ime i prezime</label>
                     <input type="text" placeholder="Ime" value="<?php echo $_SESSION['ime'] ?> <?php echo $_SESSION['prezime'] ?>" class="form-control" readonly>
                     <label>Korisničko ime</label>
                     <input type="text" value="<?php echo $_SESSION['username'] ?>" class="form-control" readonly>
                     <label>E-mail</label>
                     <input type="text" value="<?php echo $_SESSION['email'] ?>" placeholder="example@mail.com" class="form-control" readonly>
                     <label>Lozinka</label>
                     <input type="password" value="<?php echo $_SESSION['password'] ?>" placeholder="Lozinka" class="form-control" readonly>
                  </div>
               </div>
            </div>
            <script src="../js/showForm.js"></script>
            <div class="col">
               <button type="button" class="btn btn-primary mm-btn" data-toggle="modal" data-target="#exampleModalLong"><span class="pe-7s-add-user"></span> Dodajte novog administratora</button>
               <?php
                  $con = new PDO("mysql:host=localhost;dbname=cvetkovic", "root","");
                  $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                  $sql="SELECT ID,ime,prezime,username,email,vrsta FROM registrovani";
                  $exc = $con->query($sql);
                  $nbrow = 0;
                  echo "<table border=1 id='korisniciTab' class='table'><th>ID</th><th>Ime</th><th>Prezime</th><th>Korisnicko ime</th><th>Email</th><th>Privilegija</th><th>Akcija</th>";
                  while($row = $exc->fetch()){
                      echo "<tr><td>". $row["ID"] ."</td><td>" . $row["ime"] . "</td> <td>". $row["prezime"] ."</td><td>" . $row["username"] ."</td> <td>". $row["email"] ."</td><td>" . $row["vrsta"] . "</td><td><a href='del-korisnika.php?id=" .$row["ID"] ."'>Obrisati</a></td>"; 
                      echo "</tr>";
                      $nbrow++;
                  }
                  ?>
               <button id="dugmePokaziKO" type="button" onclick="pokaziKorisnike()" class="btn btn-primary mm-btn">Profili</button>
               <?php
                  $con = new PDO("mysql:host=localhost;dbname=cvetkovic", "root","");
                  $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                  $sql="SELECT ID,soba,imePrezime,tel FROM kontakti";
                  $exc = $con->query($sql);
                  $nbrow = 0;
                  echo "<table border=1 id='narudzbineTab' class='table'><th>ID</th><th>Soba</th><th>Ime i prezime</th><th>Telefon</th><th>Akcija</th>";
                  while($row = $exc->fetch()){
                      echo "<tr><td>" . $row["ID"] . "</td><td>" . $row["soba"] . "</td><td>". $row['imePrezime'] ."</td><td>". $row['tel'] ."</td><td><a href='del-raspolozivosti.php?id=" .$row["ID"] ."'>Obrisati</a></td>";
                      echo "</tr>";
                      $nbrow++;
                  }
                  ?>
               <button id="dugmePokaziNA" type="button" onclick="pokaziRaspolozivost()" class="btn btn-primary mm-btn">Raspoloživost</button>

               <?php
                  $con = new PDO("mysql:host=localhost;dbname=cvetkovic", "root","");
                  $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                  $sql="SELECT * FROM pitanja";
                  $exc = $con->query($sql);
                  $nbrow = 0;
                  echo "<table border=1 id='pitanjaTab' class='table'><th>ID</th><th>Ime</th><th>Email</th><th>Dodatno</th><th>Akcija</th>";
                  while($row = $exc->fetch()){
                      echo "<tr><td>" . $row["ID"] . "</td> <td>". $row["ime"] ."</td><td>" . $row["email"] . "</td><td>". $row['dodInfo'] ."</td><td><a href='del-pitanja.php?id=" .$row["ID"] ."'>Obrisati</a></td>"; 
                      echo "</tr>";
                      $nbrow++;
                  }
                  ?>
               <button id="dugmePokaziPI" type="button" onclick="pokaziPitanja()" class="btn btn-primary mm-btn">Pitanja</button>
            </div>
         </div>
      </div>
      </div>
      <!-- Modal -->
      <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLongTitle">Dodajte novog administratora</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <form return="false" method="post" action="admin.php">
                     <label>Ime</label>
                     <input type="text" name="imeAD" class="form-control" required>
                     <label>Prezime</label>
                     <input type="text" name="prezimeAD" class="form-control" required>
                     <label>Korisničko ime</label>
                     <input type="text" name="usernameAD" class="form-control" required>
                     <label>E-mail</label>
                     <input type="email" name="emailAD" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" class="form-control" required>
                     <label>Lozinka</label>
                     <input type="password" name="passwordAD" class="form-control" required>
                     <button type="submit" name="reg_admin" class="btn btn-primary">Potvrdi</button>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <?php include('-footer.php'); ?>
   </body>
</html>